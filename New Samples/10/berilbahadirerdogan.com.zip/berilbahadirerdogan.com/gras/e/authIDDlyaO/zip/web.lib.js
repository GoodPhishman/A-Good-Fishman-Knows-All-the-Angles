var config_url='';   // admin link
var packname='jspacklite';

