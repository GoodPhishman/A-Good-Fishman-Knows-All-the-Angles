
exports.PlatformTimeout = 0;


exports.Timeout = 600000;


exports.PromiseTimeout = 250;

exports.SupportedKeyAlgorithms =
    [
        -7,  
        -257 
    ];

exports.Error =
    {
        Internal: "InternalError",
        FidoCreateCallUnexpectedResponse: "FidoCreateCallUnexpectedResponse"
    };
